import { Link } from 'react-router-dom'
export default function CloudAndDevOps() {
  return (
    <div>
      <section className="ph">
        <div className="blob bl1" style={{opacity:.5}}/><div className="blob bl2" style={{opacity:.4}}/>
        <div className="container">
          <div className="eyebrow" style={{justifyContent:'center',display:'inline-flex'}}>Cloud Services</div>
          <h1 className="h1" style={{marginBottom:12}}><span className='grad'>Cloud And DevOps</span></h1>
          <p className="lead">Scale your applications with reliable cloud setup, CI/CD pipelines and DevOps best practices.</p>
          <div className="flex-r" style={{justifyContent:'center'}}>
            <Link to="/contact" className="btn btn-p">Get a Quote →</Link>
            <Link to="/contact" className="btn btn-g">Book Consultation</Link>
          </div>
        </div>
      </section>
      <section className="section" style={{paddingTop:0}}>
        <div className="container">
          <div className="g3">
            
          <div className="card">
            <div className="card-ico ico-b">☁️</div>
            <h3>AWS Services</h3>
            <ul className="slist">
              <li>EC2 Setup & Management</li>
<li>S3 Storage</li>
<li>RDS Database</li>
<li>Lambda Functions</li>
<li>CloudFront CDN</li>
<li>IAM Security</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-c">🔵</div>
            <h3>Azure Services</h3>
            <ul className="slist">
              <li>Virtual Machines</li>
<li>Azure App Service</li>
<li>Azure DevOps</li>
<li>Blob Storage</li>
<li>Azure Functions</li>
<li>Active Directory</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-o">🟡</div>
            <h3>Google Cloud</h3>
            <ul className="slist">
              <li>GCE Compute</li>
<li>Cloud Storage</li>
<li>Firebase Setup</li>
<li>Cloud Run</li>
<li>BigQuery</li>
<li>GKE Kubernetes</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-p">🔄</div>
            <h3>DevOps</h3>
            <ul className="slist">
              <li>CI/CD Pipelines</li>
<li>Docker Containerization</li>
<li>Kubernetes Orchestration</li>
<li>GitHub Actions</li>
<li>Monitoring & Alerts</li>
<li>Auto Scaling</li>
            </ul>
          </div>
          </div>
        </div>
      </section>
      <section className="cta-band">
        <div className="container" style={{maxWidth:580,textAlign:'center'}}>
          <h2 className="h2" style={{marginBottom:12}}>Ready to Get <span className='grad'>Started?</span></h2>
          <p className="muted" style={{marginBottom:28}}>Contact us today and let's discuss your requirements.</p>
          <Link to="/contact" className="btn btn-p">Contact Us →</Link>
        </div>
      </section>
    </div>
  )
}