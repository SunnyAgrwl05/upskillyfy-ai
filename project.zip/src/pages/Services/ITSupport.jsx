import { Link } from 'react-router-dom'
export default function ITSupport() {
  return (
    <div>
      <section className="ph">
        <div className="blob bl1" style={{opacity:.5}}/><div className="blob bl2" style={{opacity:.4}}/>
        <div className="container">
          <div className="eyebrow" style={{justifyContent:'center',display:'inline-flex'}}>Technical Support</div>
          <h1 className="h1" style={{marginBottom:12}}><span className='grad'>IT Support</span></h1>
          <p className="lead">From system setup to network management and cloud support — we keep your tech running smoothly.</p>
          <div className="flex-r" style={{justifyContent:'center'}}>
            <Link to="/contact" className="btn btn-p">Get a Quote →</Link>
            <Link to="/contact" className="btn btn-g">Book Consultation</Link>
          </div>
        </div>
      </section>
      <section className="section" style={{paddingTop:0}}>
        <div className="container">
          <div className="g3">
            
          <div className="card">
            <div className="card-ico ico-b">💻</div>
            <h3>Technical Support</h3>
            <ul className="slist">
              <li>Software Installation & Config</li>
<li>OS Setup & Troubleshooting</li>
<li>Performance Optimization</li>
<li>Device Setup</li>
<li>Email Configuration</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-c">🌐</div>
            <h3>Network Support</h3>
            <ul className="slist">
              <li>Router & Switch Setup</li>
<li>WiFi Troubleshooting</li>
<li>Network Monitoring</li>
<li>Firewall Setup</li>
<li>VPN Configuration</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-p">☁️</div>
            <h3>Cloud Support</h3>
            <ul className="slist">
              <li>AWS Setup & Management</li>
<li>Azure Support</li>
<li>Google Cloud Setup</li>
<li>Cloud Migration</li>
<li>Cost Optimization</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-g">🔐</div>
            <h3>Security Support</h3>
            <ul className="slist">
              <li>Security Audit</li>
<li>Vulnerability Assessment</li>
<li>Backup Solutions</li>
<li>Data Protection</li>
<li>Antivirus Setup</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-o">🖥️</div>
            <h3>Remote IT Support</h3>
            <ul className="slist">
              <li>Remote Desktop Support</li>
<li>Helpdesk Services</li>
<li>Ticket Resolution</li>
<li>24/7 User Assistance</li>
<li>Screen Sharing Support</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-pk">🏢</div>
            <h3>Business IT</h3>
            <ul className="slist">
              <li>IT Infrastructure Planning</li>
<li>Business Email Setup</li>
<li>Collaboration Tools</li>
<li>IT Policy Documentation</li>
<li>Vendor Management</li>
            </ul>
          </div>
          </div>
        </div>
      </section>
      <section className="cta-band">
        <div className="container" style={{maxWidth:580,textAlign:'center'}}>
          <h2 className="h2" style={{marginBottom:12}}>Ready to Get <span className='grad'>Started?</span></h2>
          <p className="muted" style={{marginBottom:28}}>Contact us today and let's discuss your requirements.</p>
          <Link to="/contact" className="btn btn-p">Contact Us →</Link>
        </div>
      </section>
    </div>
  )
}