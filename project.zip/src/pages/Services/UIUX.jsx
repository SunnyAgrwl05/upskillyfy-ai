import { Link } from 'react-router-dom'
export default function UIUXDesign() {
  return (
    <div>
      <section className="ph">
        <div className="blob bl1" style={{opacity:.5}}/><div className="blob bl2" style={{opacity:.4}}/>
        <div className="container">
          <div className="eyebrow" style={{justifyContent:'center',display:'inline-flex'}}>Design Services</div>
          <h1 className="h1" style={{marginBottom:12}}><span className='grad'>UI/UX Design</span></h1>
          <p className="lead">Beautiful, user-centric designs for websites, apps and brands — from wireframes to final handoff.</p>
          <div className="flex-r" style={{justifyContent:'center'}}>
            <Link to="/contact" className="btn btn-p">Get a Quote →</Link>
            <Link to="/contact" className="btn btn-g">Book Consultation</Link>
          </div>
        </div>
      </section>
      <section className="section" style={{paddingTop:0}}>
        <div className="container">
          <div className="g3">
            
          <div className="card">
            <div className="card-ico ico-b">🖥️</div>
            <h3>Website Design</h3>
            <ul className="slist">
              <li>Landing Page Design</li>
<li>Multi-page Websites</li>
<li>Dashboard Design</li>
<li>Portfolio Design</li>
<li>CMS Design</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-c">📱</div>
            <h3>Mobile App Design</h3>
            <ul className="slist">
              <li>iOS App Design</li>
<li>Android App Design</li>
<li>User Flow Design</li>
<li>Onboarding Screens</li>
<li>Component Libraries</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-p">🎨</div>
            <h3>Brand Identity</h3>
            <ul className="slist">
              <li>Logo Design</li>
<li>Color Palette</li>
<li>Typography System</li>
<li>Brand Guidelines</li>
<li>Social Media Kit</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-g">🔬</div>
            <h3>UX Research</h3>
            <ul className="slist">
              <li>User Interviews</li>
<li>Usability Testing</li>
<li>Persona Creation</li>
<li>Journey Mapping</li>
<li>Competitive Analysis</li>
            </ul>
          </div>
          </div>
        </div>
      </section>
      <section className="cta-band">
        <div className="container" style={{maxWidth:580,textAlign:'center'}}>
          <h2 className="h2" style={{marginBottom:12}}>Ready to Get <span className='grad'>Started?</span></h2>
          <p className="muted" style={{marginBottom:28}}>Contact us today and let's discuss your requirements.</p>
          <Link to="/contact" className="btn btn-p">Contact Us →</Link>
        </div>
      </section>
    </div>
  )
}