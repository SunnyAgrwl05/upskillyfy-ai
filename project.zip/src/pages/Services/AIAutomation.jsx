import { Link } from 'react-router-dom'
export default function AIAndAutomation() {
  return (
    <div>
      <section className="ph">
        <div className="blob bl1" style={{opacity:.5}}/><div className="blob bl2" style={{opacity:.4}}/>
        <div className="container">
          <div className="eyebrow" style={{justifyContent:'center',display:'inline-flex'}}>AI Solutions</div>
          <h1 className="h1" style={{marginBottom:12}}><span className='grad'>AI And Automation</span></h1>
          <p className="lead">From intelligent chatbots to business automation and data analytics — we bring AI to your workflow.</p>
          <div className="flex-r" style={{justifyContent:'center'}}>
            <Link to="/contact" className="btn btn-p">Get a Quote →</Link>
            <Link to="/contact" className="btn btn-g">Book Consultation</Link>
          </div>
        </div>
      </section>
      <section className="section" style={{paddingTop:0}}>
        <div className="container">
          <div className="g3">
            
          <div className="card">
            <div className="card-ico ico-b">🤖</div>
            <h3>AI Chatbots</h3>
            <ul className="slist">
              <li>Customer Support Bots</li>
<li>Lead Generation Bots</li>
<li>WhatsApp Chatbots</li>
<li>Telegram Bots</li>
<li>Multi-language Bots</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-c">⚡</div>
            <h3>Business Automation</h3>
            <ul className="slist">
              <li>Workflow Automation</li>
<li>Email Automation</li>
<li>CRM Automation</li>
<li>Invoice Processing</li>
<li>Report Generation</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-p">📊</div>
            <h3>Data Analytics</h3>
            <ul className="slist">
              <li>BI Dashboards</li>
<li>Data Visualization</li>
<li>Sales Analytics</li>
<li>KPI Tracking</li>
<li>Predictive Analytics</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-g">🧠</div>
            <h3>AI Integration</h3>
            <ul className="slist">
              <li>OpenAI / Gemini API</li>
<li>AI-powered Search</li>
<li>Content Generation</li>
<li>Image Recognition</li>
<li>Recommendation Systems</li>
            </ul>
          </div>
          </div>
        </div>
      </section>
      <section className="cta-band">
        <div className="container" style={{maxWidth:580,textAlign:'center'}}>
          <h2 className="h2" style={{marginBottom:12}}>Ready to Get <span className='grad'>Started?</span></h2>
          <p className="muted" style={{marginBottom:28}}>Contact us today and let's discuss your requirements.</p>
          <Link to="/contact" className="btn btn-p">Contact Us →</Link>
        </div>
      </section>
    </div>
  )
}