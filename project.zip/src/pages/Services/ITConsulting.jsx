import { Link } from 'react-router-dom'
export default function ITConsulting() {
  return (
    <div>
      <section className="ph">
        <div className="blob bl1" style={{opacity:.5}}/><div className="blob bl2" style={{opacity:.4}}/>
        <div className="container">
          <div className="eyebrow" style={{justifyContent:'center',display:'inline-flex'}}>Technology Consulting</div>
          <h1 className="h1" style={{marginBottom:12}}><span className='grad'>IT Consulting</span></h1>
          <p className="lead">Helping startups and businesses make the right technology decisions for sustainable growth.</p>
          <div className="flex-r" style={{justifyContent:'center'}}>
            <Link to="/contact" className="btn btn-p">Get a Quote →</Link>
            <Link to="/contact" className="btn btn-g">Book Consultation</Link>
          </div>
        </div>
      </section>
      <section className="section" style={{paddingTop:0}}>
        <div className="container">
          <div className="g3">
            
          <div className="card">
            <div className="card-ico ico-b">🚀</div>
            <h3>Startup Consulting</h3>
            <ul className="slist">
              <li>Tech Stack Selection</li>
<li>MVP Planning & Development</li>
<li>Product Roadmap</li>
<li>Team Building Guidance</li>
<li>Scaling Strategy</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-c">🔄</div>
            <h3>Digital Transformation</h3>
            <ul className="slist">
              <li>Business Process Automation</li>
<li>Legacy System Migration</li>
<li>Cloud Adoption Strategy</li>
<li>Workflow Optimization</li>
<li>Digital Roadmap</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-p">📊</div>
            <h3>Technology Strategy</h3>
            <ul className="slist">
              <li>IT Budget Planning</li>
<li>Technology Assessment</li>
<li>Software Architecture Review</li>
<li>Build vs Buy Analysis</li>
<li>Risk Management</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-g">🤖</div>
            <h3>AI Consulting</h3>
            <ul className="slist">
              <li>AI Readiness Assessment</li>
<li>AI Integration Strategy</li>
<li>Automation Opportunities</li>
<li>Data Analytics Planning</li>
<li>MLOps Consulting</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-o">☁️</div>
            <h3>Cloud Migration</h3>
            <ul className="slist">
              <li>Cloud Readiness Assessment</li>
<li>Migration Strategy</li>
<li>Platform Selection</li>
<li>Cost Optimization</li>
<li>Security Planning</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-pk">🔐</div>
            <h3>Cybersecurity Consulting</h3>
            <ul className="slist">
              <li>Security Assessment</li>
<li>Risk Analysis</li>
<li>Compliance Guidance</li>
<li>Security Architecture</li>
<li>Best Practices</li>
            </ul>
          </div>
          </div>
        </div>
      </section>
      <section className="cta-band">
        <div className="container" style={{maxWidth:580,textAlign:'center'}}>
          <h2 className="h2" style={{marginBottom:12}}>Ready to Get <span className='grad'>Started?</span></h2>
          <p className="muted" style={{marginBottom:28}}>Contact us today and let's discuss your requirements.</p>
          <Link to="/contact" className="btn btn-p">Contact Us →</Link>
        </div>
      </section>
    </div>
  )
}