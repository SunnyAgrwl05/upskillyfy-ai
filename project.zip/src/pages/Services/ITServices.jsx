import { Link } from 'react-router-dom'
export default function ITServices() {
  return (
    <div>
      <section className="ph">
        <div className="blob bl1" style={{opacity:.5}}/><div className="blob bl2" style={{opacity:.4}}/>
        <div className="container">
          <div className="eyebrow" style={{justifyContent:'center',display:'inline-flex'}}>Software Development</div>
          <h1 className="h1" style={{marginBottom:12}}><span className='grad'>IT Services</span></h1>
          <p className="lead">From websites to full-stack apps, mobile apps and custom enterprise software — we build it all.</p>
          <div className="flex-r" style={{justifyContent:'center'}}>
            <Link to="/contact" className="btn btn-p">Get a Quote →</Link>
            <Link to="/contact" className="btn btn-g">Book Consultation</Link>
          </div>
        </div>
      </section>
      <section className="section" style={{paddingTop:0}}>
        <div className="container">
          <div className="g3">
            
          <div className="card">
            <div className="card-ico ico-b">🌐</div>
            <h3>Web Development</h3>
            <ul className="slist">
              <li>Business & Portfolio Websites</li>
<li>E-Commerce Solutions</li>
<li>LMS / CRM / SaaS Platforms</li>
<li>Admin Panels & Student Portals</li>
<li>Landing Pages & Blogs</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-p">📱</div>
            <h3>Mobile App Development</h3>
            <ul className="slist">
              <li>Android & iOS Apps</li>
<li>Flutter / React Native</li>
<li>Educational Apps</li>
<li>Business Apps</li>
<li>E-Commerce Apps</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-g">⚙️</div>
            <h3>Custom Software</h3>
            <ul className="slist">
              <li>ERP & CRM Systems</li>
<li>School Management</li>
<li>Hospital Management</li>
<li>Inventory Systems</li>
<li>HR Management</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-c">⚛️</div>
            <h3>Frontend Tech</h3>
            <ul className="slist">
              <li>React.js & Next.js</li>
<li>HTML / CSS / Tailwind</li>
<li>TypeScript</li>
<li>Responsive Design</li>
<li>Performance Optimization</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-o">🔧</div>
            <h3>Backend Tech</h3>
            <ul className="slist">
              <li>Node.js & Express.js</li>
<li>Python Django / Flask</li>
<li>Java Spring Boot</li>
<li>REST APIs</li>
<li>GraphQL</li>
            </ul>
          </div>

          <div className="card">
            <div className="card-ico ico-pk">🗄️</div>
            <h3>Database & Cloud</h3>
            <ul className="slist">
              <li>MongoDB & PostgreSQL</li>
<li>MySQL / Firebase</li>
<li>AWS / Azure / GCP</li>
<li>Docker & Kubernetes</li>
<li>CI/CD Pipelines</li>
            </ul>
          </div>
          </div>
        </div>
      </section>
      <section className="cta-band">
        <div className="container" style={{maxWidth:580,textAlign:'center'}}>
          <h2 className="h2" style={{marginBottom:12}}>Ready to Get <span className='grad'>Started?</span></h2>
          <p className="muted" style={{marginBottom:28}}>Contact us today and let's discuss your requirements.</p>
          <Link to="/contact" className="btn btn-p">Contact Us →</Link>
        </div>
      </section>
    </div>
  )
}