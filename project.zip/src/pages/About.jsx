import { Link } from 'react-router-dom'
const PILLARS = [
  { ico:'🎓', cls:'ico-b', t:'Learn', d:'Courses, roadmaps, DSA, notes, certifications and branch-wise resources.' },
  { ico:'🚀', cls:'ico-g', t:'Grow', d:'Internships, placements, resume building, mock interviews, career guidance.' },
  { ico:'💻', cls:'ico-c', t:'Build', d:'IT services, web dev, app dev, AI solutions and custom software.' },
  { ico:'🤝', cls:'ico-p', t:'Transform', d:'IT consulting, startup guidance, digital transformation and tech strategy.' },
]
export default function About() {
  return (
    <div>
      <section className="ph">
        <div className="blob bl1" style={{opacity:.5}}/><div className="blob bl2" style={{opacity:.4}}/>
        <div className="container">
          <div className="eyebrow" style={{justifyContent:'center',display:'inline-flex'}}>About Us</div>
          <h1 className="h1" style={{marginBottom:12}}>About <span className="grad">Upskillyfy</span></h1>
          <p className="lead">A Career Development, IT Services & Technology Consulting Platform for Students, Professionals, Startups, and Businesses.</p>
        </div>
      </section>
      <section className="section" style={{paddingTop:0}}>
        <div className="container">
          <div className="g2" style={{gap:64,alignItems:'start'}}>
            <div>
              <div className="eyebrow">Our Story</div>
              <h2 className="h2">From Campus to <span className="grad">Company</span></h2>
              <p style={{marginTop:16,lineHeight:1.85}}>Upskillyfy started as a small student community in Patna, Bihar — sharing internship links and DSA resources. We realized that thousands of students across all branches struggle to find verified opportunities in one place.</p>
              <p style={{marginTop:14,lineHeight:1.85}}>Today, Upskillyfy is growing into a full-fledged EdTech + IT Services + IT Consulting platform — serving students, startups and businesses.</p>
              <div className="hbox" style={{marginTop:28}}>
                <p style={{color:'#f1f5f9',fontStyle:'italic',fontSize:'1.02rem',lineHeight:1.75}}>"Empower every student, professional and business through education, technology and innovation — regardless of branch, college tier or background."</p>
              </div>
              <div className="flex-r" style={{marginTop:28}}>
                <Link to="/contact" className="btn btn-p">Get in Touch →</Link>
                <Link to="/community/events" className="btn btn-g">Join Community</Link>
              </div>
            </div>
            <div>
              <div className="eyebrow">Our 4 Pillars</div>
              <div style={{display:'flex',flexDirection:'column',gap:14,marginTop:8}}>
                {PILLARS.map((p,i) => (
                  <div key={i} style={{display:'flex',gap:16,alignItems:'flex-start',padding:20,background:'rgba(15,23,42,.7)',border:'1px solid rgba(255,255,255,.07)',borderRadius:14}}>
                    <div className={`card-ico ${p.cls}`} style={{marginBottom:0,flexShrink:0}}>{p.ico}</div>
                    <div><h3>{p.t}</h3><p style={{marginTop:6,fontSize:'.87rem'}}>{p.d}</p></div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="section section-alt">
        <div className="container">
          <div className="sec-head">
            <div className="eyebrow">Team</div>
            <h2 className="h2">Built by <span className="grad">Students, for Everyone</span></h2>
          </div>
          <div className="g4">
            {[['👨‍💻','Founder & Tech Lead','Engineering student driving the vision of Upskillyfy.'],['📚','Resource Team','Curates DSA sheets, notes and placement material.'],['💻','Development Team','Builds the platform, client projects and IT solutions.'],['📢','Community Team','Manages events, ambassador program and community.']].map(([e,r,d],i)=>(
              <div key={i} className="card" style={{textAlign:'center'}}>
                <div style={{fontSize:'2.2rem',marginBottom:14}}>{e}</div>
                <h3 style={{fontSize:'1rem'}}>{r}</h3>
                <p style={{marginTop:8}}>{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}