import { Link } from 'react-router-dom'
import { useEffect, useRef } from 'react'
import './Home.css'
import TechCarousel from '../components/TechCarousel'

const SERVICES = [
  {
    icon: '🎓',
    cls: 'ico-b',
    title: 'Education & Career',
    desc: 'Internships, placement prep, DSA Hub, resume building, mock interviews and career counseling.',
    link: '/career/internships',
  },
  {
    icon: '💻',
    cls: 'ico-c',
    title: 'IT Services',
    desc: 'Website, web apps, mobile apps, e-commerce, SaaS platforms and custom software development.',
    link: '/services/it-services',
  },
  {
    icon: '🛠️',
    cls: 'ico-p',
    title: 'IT Support',
    desc: 'Technical helpdesk, remote support, network setup, cloud support and server management.',
    link: '/services/it-support',
  },
  {
    icon: '👨‍💼',
    cls: 'ico-g',
    title: 'IT Consulting',
    desc: 'Startup consulting, digital transformation, MVP planning, AI consulting and cloud migration.',
    link: '/services/it-consulting',
  },
  {
    icon: '🤖',
    cls: 'ico-o',
    title: 'AI & Automation',
    desc: 'AI chatbots, WhatsApp bots, CRM automation, workflow automation and data analytics dashboards.',
    link: '/services/ai-automation',
  },
  {
    icon: '🌐',
    cls: 'ico-pk',
    title: 'Community Programs',
    desc: 'Workshops, webinars, hackathons, campus ambassador program and tech meetups.',
    link: '/community/events',
  },
]

const WHY = [
  {
    icon: '⚡',
    title: 'Student-First',
    desc: 'Built by students who understand what you actually need.',
  },
  {
    icon: '🏆',
    title: 'Industry Experts',
    desc: 'Resources from professionals with real-world experience.',
  },
  {
    icon: '🔒',
    title: 'Verified Listings',
    desc: 'Every internship is verified before publishing.',
  },
  {
    icon: '🚀',
    title: 'End-to-End',
    desc: 'From learning to internships to IT consulting — full journey.',
  },
]

const BRANCHES = [
  'CSE',
  'Information Technology',
  'ECE',
  'Electrical (EE)',
  'Mechanical (ME)',
  'Civil',
  'AI & Data Science',
  'Chemical',
  'BCA/MCA',
  'MBA',
]

export default function Home() {
  const cardRef = useRef(null)

  useEffect(() => {
    const card = cardRef.current

    if (!card) return

    const onMove = (e) => {
      const r = card.getBoundingClientRect()

      const rx =
        ((e.clientY - r.top - r.height / 2) / (r.height / 2)) * -6

      const ry =
        ((e.clientX - r.left - r.width / 2) / (r.width / 2)) * 9

      card.style.transform = `
        perspective(1000px)
        rotateX(${rx}deg)
        rotateY(${ry}deg)
        translateY(-6px)
      `
    }

    const onLeave = () => {
      card.style.transform =
        'perspective(1000px) rotateY(-10deg) rotateX(4deg)'
    }

    card.addEventListener('mousemove', onMove)
    card.addEventListener('mouseleave', onLeave)

    return () => {
      card.removeEventListener('mousemove', onMove)
      card.removeEventListener('mouseleave', onLeave)
    }
  }, [])

  return (
    <>
      {/* =====================================================
          HERO
      ====================================================== */}

      <section className="hero">
        <div className="blob bl1" />
        <div className="blob bl2" />
        <div className="blob bl3" />

        <div className="container">
          <div className="hero-grid">
            <div>
              <div className="hero-tag">
                <div className="live-dot" />
                EdTech · IT Services · IT Consulting
              </div>

              <h1 className="h1" style={{ marginBottom: 16 }}>
                Learn. Build.
                <br />
                <span className="grad">Grow. Transform.</span>
              </h1>

              <p className="hero-sub">
                Empowering students, professionals, startups, and businesses
                through education, technology, and innovation — all under one
                roof.
              </p>

              <div className="flex-r">
                <Link
                  to="/career/internships"
                  className="btn btn-p"
                >
                  Explore Internships →
                </Link>

                <Link
                  to="/services/it-services"
                  className="btn btn-g"
                >
                  Our Services
                </Link>

                <Link
                  to="/contact"
                  className="btn btn-c"
                >
                  Join Community
                </Link>
              </div>

              <div className="hero-stats">
                {[
                  ['5000+', 'Students Reached'],
                  ['120+', 'Active Internships'],
                  ['50+', 'Projects Delivered'],
                  ['8+', 'Branches Covered'],
                ].map(([n, l], i) => (
                  <div key={i}>
                    <div className="stat-n">{n}</div>
                    <div className="stat-l">{l}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* 3D Terminal Card */}

            <div>
              <div className="term-card" ref={cardRef}>
                <div className="term-bar">
                  <div className="tdot tr" />
                  <div className="tdot ty" />
                  <div className="tdot tg" />

                  <span className="term-title">
                    Upskillyfy — dashboard.exe
                  </span>
                </div>

                <div className="term-body">
                  <div className="t-row">
                    <span className="t-prompt">$</span>
                    <span className="t-cmd">whoami</span>
                  </div>

                  <div className="t-row">
                    <span className="t-out">
                      student @ any_branch · any_year
                    </span>
                  </div>

                  <div
                    style={{
                      fontSize: '.72rem',
                      color: '#475569',
                      fontFamily: 'monospace',
                      margin: '8px 0 4px',
                    }}
                  >
                    <span className="t-comment">
                      // Active services & opportunities
                    </span>
                  </div>

                  <div className="t-items">
                    {[
                      ['🚀', 'SDE Internship Open', 'NEW'],
                      ['🤖', 'AI Solutions', 'LIVE'],
                      ['💻', 'Web Dev Projects', '12+'],
                      ['🛠️', 'IT Support 24/7', 'ON'],
                      ['👨‍💼', 'Startup Consulting', 'BOOK'],
                      ['🧠', 'DSA Hub', '450+'],
                    ].map(([ic, nm, bd], i) => (
                      <div key={i} className="t-item">
                        <div className="t-item-l">
                          <span>{ic}</span>
                          <span>{nm}</span>
                        </div>

                        <span className="t-badge">{bd}</span>
                      </div>
                    ))}
                  </div>

                  <div className="t-foot">
                    <div>
                      <div className="t-foot-l">Community</div>
                      <div className="t-foot-n">
                        5,000+ Students Active
                      </div>
                    </div>

                    <span style={{ fontSize: '1.3rem' }}>🟢</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <hr className="divider" />

      {/* =====================================================
          MODERN AI / 3D TECHNOLOGY CAROUSEL
          Google Cloud inspired moving-card section
      ====================================================== */}

      <TechCarousel />

      <hr className="divider" />

      {/* =====================================================
          SERVICES
      ====================================================== */}

      <section className="section section-alt">
        <div className="container">
          <div className="sec-head">
            <div className="eyebrow">What We Do</div>

            <h2 className="h2">
              One Platform.{' '}
              <span className="grad">Endless Possibilities.</span>
            </h2>

            <p>
              From student career growth to enterprise IT consulting,
              Upskillyfy serves students, professionals, startups, and
              businesses.
            </p>
          </div>

          <div className="g3">
            {SERVICES.map((s, i) => (
              <Link
                to={s.link}
                key={i}
                style={{ textDecoration: 'none' }}
              >
                <div
                  className="card"
                  style={{
                    height: '100%',
                    cursor: 'pointer',
                  }}
                >
                  <div className={`card-ico ${s.cls}`}>
                    {s.icon}
                  </div>

                  <h3>{s.title}</h3>

                  <p>{s.desc}</p>

                  <div className="card-arr">
                    Explore →
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <hr className="divider" />

      {/* =====================================================
          WHY US
      ====================================================== */}

      <section className="section">
        <div className="container">
          <div className="sec-head">
            <div className="eyebrow">Why Upskillyfy</div>

            <h2 className="h2">
              Your{' '}
              <span className="grad">
                Growth Partner
              </span>{' '}
              in Tech & Career
            </h2>
          </div>

          <div className="g4">
            {WHY.map((w, i) => (
              <div
                key={i}
                className="card"
                style={{ textAlign: 'center' }}
              >
                <div
                  style={{
                    fontSize: '2.2rem',
                    marginBottom: 14,
                  }}
                >
                  {w.icon}
                </div>

                <h3>{w.title}</h3>

                <p style={{ marginTop: 8 }}>
                  {w.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <hr className="divider" />

      {/* =====================================================
          BRANCHES
      ====================================================== */}

      <section className="section section-alt">
        <div
          className="container"
          style={{ textAlign: 'center' }}
        >
          <div
            className="eyebrow"
            style={{
              justifyContent: 'center',
              display: 'inline-flex',
            }}
          >
            All Branches Welcome
          </div>

          <h2
            className="h2"
            style={{ marginBottom: 24 }}
          >
            Not Just CSE —{' '}
            <span className="grad">
              Every Branch
            </span>{' '}
            Covered
          </h2>

          <p
            className="muted"
            style={{
              maxWidth: 560,
              margin: '0 auto 32px',
            }}
          >
            Resources, internships, and opportunities
            for every engineering stream and beyond.
          </p>

          <div
            className="pill-row"
            style={{ justifyContent: 'center' }}
          >
            {BRANCHES.map((branch, i) => (
              <span
                key={i}
                className="pill"
              >
                {branch}
              </span>
            ))}
          </div>
        </div>
      </section>

      <hr className="divider" />

      {/* =====================================================
          CTA
      ====================================================== */}

      <section className="cta-band">
        <div
          className="container"
          style={{
            maxWidth: 680,
            textAlign: 'center',
          }}
        >
          <div
            className="eyebrow"
            style={{
              justifyContent: 'center',
              display: 'inline-flex',
            }}
          >
            Start Today — It's Free
          </div>

          <h2
            className="h2"
            style={{ marginBottom: 12 }}
          >
            Ready to{' '}
            <span className="grad">
              Level Up?
            </span>
          </h2>

          <p
            className="muted"
            style={{
              marginBottom: 32,
              fontSize: '1.05rem',
            }}
          >
            Join 5,000+ students and businesses already
            growing with Upskillyfy.
          </p>

          <div
            className="flex-r"
            style={{ justifyContent: 'center' }}
          >
            <Link
              to="/register"
              className="btn btn-p"
            >
              Join Free →
            </Link>

            <Link
              to="/career/internships"
              className="btn btn-c"
            >
              Explore Internships
            </Link>

            <Link
              to="/contact"
              className="btn btn-g"
            >
              Talk to Us
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}