import { Link } from "react-router-dom";
import { useState, useRef, useEffect } from "react";
import { Mail, Globe, ChevronDown } from "lucide-react";
import { newsletterAPI } from "../api";
import "./Footer.css";

/* Social icons as plain inline SVGs — lucide-react removed brand/logo
   icons (Facebook, Twitter, Instagram, Linkedin, Youtube) in newer
   versions, so we render these ourselves instead of importing them. */
const LinkedinIcon = (props) => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" {...props}>
    <path d="M20.45 20.45h-3.55v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.36V9h3.41v1.56h.05c.47-.9 1.63-1.85 3.36-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29zM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12zM7.12 20.45H3.56V9h3.56v11.45z" />
  </svg>
);
const InstagramIcon = (props) => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" {...props}>
    <path d="M12 2c2.72 0 3.06.01 4.12.06 1.06.05 1.79.22 2.43.47.66.26 1.22.6 1.77 1.16.51.5.9 1.11 1.16 1.77.25.64.42 1.37.47 2.43.05 1.06.06 1.4.06 4.12 0 2.72-.01 3.06-.06 4.12-.05 1.06-.22 1.79-.47 2.43a4.9 4.9 0 0 1-1.16 1.77 4.9 4.9 0 0 1-1.77 1.16c-.64.25-1.37.42-2.43.47-1.06.05-1.4.06-4.12.06-2.72 0-3.06-.01-4.12-.06-1.06-.05-1.79-.22-2.43-.47a4.9 4.9 0 0 1-1.77-1.16 4.9 4.9 0 0 1-1.16-1.77c-.25-.64-.42-1.37-.47-2.43C2.01 15.06 2 14.72 2 12c0-2.72.01-3.06.06-4.12.05-1.06.22-1.79.47-2.43.26-.66.6-1.22 1.16-1.77a4.9 4.9 0 0 1 1.77-1.16c.64-.25 1.37-.42 2.43-.47C8.94 2.01 9.28 2 12 2zm0 1.8c-2.67 0-2.99.01-4.04.06-.98.05-1.5.2-1.86.34-.47.18-.8.4-1.15.75-.36.35-.57.68-.75 1.15-.14.36-.3.88-.34 1.86-.05 1.05-.06 1.37-.06 4.04 0 2.67.01 2.99.06 4.04.05.98.2 1.5.34 1.86.18.47.4.8.75 1.15.35.36.68.57 1.15.75.36.14.88.3 1.86.34 1.05.05 1.37.06 4.04.06 2.67 0 2.99-.01 4.04-.06.98-.05 1.5-.2 1.86-.34.47-.18.8-.4 1.15-.75.36-.35.57-.68.75-1.15.14-.36.3-.88.34-1.86.05-1.05.06-1.37.06-4.04 0-2.67-.01-2.99-.06-4.04-.05-.98-.2-1.5-.34-1.86a3.1 3.1 0 0 0-.75-1.15 3.1 3.1 0 0 0-1.15-.75c-.36-.14-.88-.3-1.86-.34-1.05-.05-1.37-.06-4.04-.06zm0 3.4a4.8 4.8 0 1 1 0 9.6 4.8 4.8 0 0 1 0-9.6zm0 7.92a3.12 3.12 0 1 0 0-6.24 3.12 3.12 0 0 0 0 6.24zm6.11-8.11a1.12 1.12 0 1 1-2.24 0 1.12 1.12 0 0 1 2.24 0z" />
  </svg>
);
const YoutubeIcon = (props) => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" {...props}>
    <path d="M23.5 6.19a3.02 3.02 0 0 0-2.12-2.13C19.5 3.5 12 3.5 12 3.5s-7.5 0-9.38.56A3.02 3.02 0 0 0 .5 6.19 31.6 31.6 0 0 0 0 12a31.6 31.6 0 0 0 .5 5.81 3.02 3.02 0 0 0 2.12 2.13C4.5 20.5 12 20.5 12 20.5s7.5 0 9.38-.56a3.02 3.02 0 0 0 2.12-2.13A31.6 31.6 0 0 0 24 12a31.6 31.6 0 0 0-.5-5.81zM9.6 15.6V8.4l6.3 3.6-6.3 3.6z" />
  </svg>
);
const XIcon = (props) => (
  <svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor" {...props}>
    <path d="M18.9 2H22l-7.6 8.7L23.3 22h-7.2l-5.6-7.3L4 22H1l8.1-9.3L1 2h7.3l5.1 6.7L18.9 2zm-1.3 18h2l-5.7-7.4-1.6-2.1L5.2 4H3.2l6 7.8 1.6 2.1L17.6 20z" />
  </svg>
);
const FacebookIcon = (props) => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" {...props}>
    <path d="M22 12a10 10 0 1 0-11.56 9.88v-6.99H7.9V12h2.54V9.8c0-2.5 1.5-3.89 3.78-3.89 1.09 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56V12h2.78l-.44 2.89h-2.34v6.99A10 10 0 0 0 22 12z" />
  </svg>
);

export default function Footer() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [language, setLanguage] = useState("en");
  const [langOpen, setLangOpen] = useState(false);
  const langRef = useRef(null);

  const languages = {
    en: "English",
    hi: "हिन्दी (Hindi)",
    bn: "বাংলা (Bengali)",
    ta: "தமிழ் (Tamil)",
    te: "తెలుగు (Telugu)",
    mr: "मराठी (Marathi)",
    gu: "ગુજરાતી (Gujarati)",
    kn: "ಕನ್ನಡ (Kannada)",
    ml: "മലയാളം (Malayalam)",
    pa: "ਪੰਜਾਬੀ (Punjabi)",
    ur: "اردو (Urdu)",
    or: "ଓଡ଼ିଆ (Odia)",
    de: "Deutsch",
    es: "Español",
    fr: "Français",
    it: "Italiano",
    pt: "Português",
    nl: "Nederlands",
    ru: "Русский",
    zh: "中文",
    ja: "日本語",
    ko: "한국어",
    ar: "العربية",
    id: "Bahasa Indonesia",
    vi: "Tiếng Việt",
    th: "ไทย",
    tr: "Türkçe",
  };

  useEffect(() => {
    function handleClickOutside(e) {
      if (langRef.current && !langRef.current.contains(e.target)) {
        setLangOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSubscribe = async (e) => {
    e.preventDefault();

    if (!email.trim()) {
      setMessage("Please enter your email address.");
      return;
    }

    try {
      setLoading(true);
      setMessage("");

      if (newsletterAPI?.subscribe) {
        await newsletterAPI.subscribe(email);
      }

      setMessage("You're subscribed successfully! 🎉");
      setEmail("");
    } catch (error) {
      setMessage(
        error?.response?.data?.message ||
        "Something went wrong. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  const socialLinks = [
    { name: "LinkedIn", Icon: LinkedinIcon, url: "https://www.linkedin.com/", className: "linkedin" },
    { name: "Instagram", Icon: InstagramIcon, url: "https://www.instagram.com/upskillyfy/", className: "instagram" },
    { name: "YouTube", Icon: YoutubeIcon, url: "https://www.youtube.com/@TechWithSunny90", className: "youtube" },
    { name: "X", Icon: XIcon, url: "https://x.com/SunnyTechLead", className: "x" },
    { name: "Facebook", Icon: FacebookIcon, url: "https://www.facebook.com/", className: "facebook" },
  ];

  // Shortened link columns — duplicates removed, only essential links kept
  const columns = [
    {
      title: "Company",
      links: [
        { to: "/about", label: "About Upskillyfy" },
        { to: "/about", label: "Our Mission" },
        { to: "/portfolio", label: "Portfolio" },
        { to: "/contact", label: "Contact Us" },
      ],
    },
    {
      title: "Services",
      links: [
        { to: "/services/it-services", label: "IT Services" },
        { to: "/services/it-consulting", label: "IT Consulting" },
        { to: "/services/ai-automation", label: "AI & Automation" },
        { to: "/services/cloud", label: "Cloud & DevOps" },
      ],
    },
    {
      title: "Career Hub",
      links: [
        { to: "/career/internships", label: "Internships" },
        { to: "/career/placements", label: "Placements" },
        { to: "/career/dsa-hub", label: "DSA Hub" },
        { to: "/career/resume-builder", label: "Resume Builder" },
      ],
    },
    {
      title: "Learning & Community",
      links: [
        { to: "/learning/courses", label: "Courses" },
        { to: "/learning/roadmaps", label: "Roadmaps" },
        { to: "/community/events", label: "Events" },
        { to: "/community/ambassador", label: "Ambassador Program" },
      ],
    },
  ];

  return (
    <footer className="up-footer">

      {/* MAIN FOOTER — shortened to 4 columns, no duplicate links */}
      <div className="up-footer-main">
        {columns.map((col) => (
          <div className="up-footer-column" key={col.title}>
            <h3>{col.title}</h3>
            {col.links.map((link) => (
              <Link key={link.label} to={link.to}>{link.label}</Link>
            ))}
          </div>
        ))}
      </div>

      {/* NEWSLETTER */}
      <div className="up-footer-newsletter">
        <div className="up-newsletter-info">
          <div className="up-newsletter-icon">
            <Mail size={20} />
          </div>
          <div>
            <h2>Subscribe to our newsletter</h2>
            <p>Get the latest updates on courses, career opportunities, events and tech resources.</p>
          </div>
        </div>

        <form className="up-newsletter-form" onSubmit={handleSubscribe}>
          <div className="up-email-box">
            <Mail size={16} />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email address"
              aria-label="Email address"
            />
          </div>
          <button type="submit" disabled={loading}>
            {loading ? "Subscribing..." : "Subscribe"}
            <span>→</span>
          </button>
        </form>

        {message && <p className="up-newsletter-message">{message}</p>}
      </div>

      {/* BOTTOM BAR */}
      <div className="up-footer-bottom">
        <div className="up-footer-legal">
          <Link to="/about">About</Link>
          <span>|</span>
          <Link to="/privacy">Privacy</Link>
          <span>|</span>
          <Link to="/terms">Terms</Link>
        </div>

        {/* SOCIALS — real icons now, not text glyphs */}
        <div className="up-footer-socials">
          {socialLinks.map(({ name, Icon, url, className }) => (
            <a
              key={name}
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              className={`up-social-icon ${className}`}
              aria-label={name}
              title={name}
            >
              <Icon />
            </a>
          ))}
        </div>

        {/* LANGUAGE — Google Cloud style custom dropdown */}
        <div className="up-language-wrapper" ref={langRef}>
          <button
            type="button"
            className="up-language-trigger"
            onClick={() => setLangOpen((o) => !o)}
            aria-haspopup="listbox"
            aria-expanded={langOpen}
          >
            <Globe size={15} />
            <span>{languages[language]}</span>
            <ChevronDown size={14} className={`up-language-chevron ${langOpen ? "open" : ""}`} />
          </button>

          {langOpen && (
            <ul className="up-language-menu" role="listbox">
              {Object.entries(languages).map(([code, name]) => (
                <li
                  key={code}
                  role="option"
                  aria-selected={code === language}
                  className={`up-language-option ${code === language ? "selected" : ""}`}
                  onClick={() => {
                    setLanguage(code);
                    setLangOpen(false);
                  }}
                >
                  {name}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* COPYRIGHT */}
      <div className="up-footer-copyright">
        <span>© {new Date().getFullYear()} Upskillyfy. All rights reserved.</span>
        <span className="up-footer-made">Made with ❤️ in India 🇮🇳</span>
      </div>

      <div id="google_translate_element" className="up-google-translate" />
    </footer>
  );
}