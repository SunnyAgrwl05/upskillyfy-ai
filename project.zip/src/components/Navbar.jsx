import { useState, useEffect, useRef } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useTheme } from '../context/ThemeContext'

const NAV = [
  {
    label: 'Services',
    intro: {
      title: 'Everything your business needs to go digital',
      desc: 'From day-to-day IT support to AI-powered automation — we build and manage it so you can focus on growth.',
      cta: 'Explore all services',
      to: '/services/it-services',
    },
    columns: [
      {
        heading: 'Core services',
        items: [
          {
            label: 'IT Services',
            desc: 'Full-stack development and support.',
            to: '/services/it-services'
          },
          {
            label: 'IT Support',
            desc: '24/7 helpdesk and maintenance.',
            to: '/services/it-support'
          },
          {
            label: 'IT Consulting',
            desc: 'Strategy and technology roadmaps.',
            to: '/services/it-consulting'
          },
        ],
      },
      {
        heading: 'Emerging tech',
        items: [
          {
            label: 'AI & Automation',
            desc: 'Automate workflows with AI agents.',
            to: '/services/ai-automation'
          },
          {
            label: 'UI/UX Design',
            desc: 'Product design that converts.',
            to: '/services/uiux'
          },
          {
            label: 'Cloud & DevOps',
            desc: 'Scalable infrastructure, managed.',
            to: '/services/cloud'
          },
        ],
      },
    ],
  },

  {
    label: 'Career Hub',
    intro: {
      title: 'Launch your career, not just your resume',
      desc: 'Internships, placements, and interview prep built for students who want real outcomes.',
      cta: 'Browse internships',
      to: '/career/internships',
    },
    columns: [
      {
        heading: 'Get hired',
        items: [
          {
            label: 'Internships',
            desc: 'Filter by branch, mode, and stipend.',
            to: '/career/internships'
          },
          {
            label: 'Placements',
            desc: 'Company drives and referrals.',
            to: '/career/placements'
          },
        ],
      },
      {
        heading: 'Prep & tools',
        items: [
          {
            label: 'DSA Hub',
            desc: 'Structured problem sets by topic.',
            to: '/career/dsa'
          },
          {
            label: 'Resume Builder',
            desc: 'ATS-friendly resumes in minutes.',
            to: '/career/resume'
          },
        ],
      },
    ],
  },

  {
    label: 'Learning',
    intro: {
      title: 'Learn what actually gets you hired',
      desc: 'Courses, roadmaps, and curated resources mapped to real industry roles.',
      cta: 'View all courses',
      to: '/learning/courses',
    },
    columns: [
      {
        heading: 'Learn',
        items: [
          {
            label: 'Courses',
            desc: 'Self-paced, project-based learning.',
            to: '/learning/courses'
          },
          {
            label: 'Roadmaps',
            desc: 'Step-by-step paths by role.',
            to: '/learning/roadmaps'
          },
        ],
      },
      {
        heading: 'Resources',
        items: [
          {
            label: 'Resources',
            desc: 'Notes, sheets, and reading lists.',
            to: '/learning/resources'
          },
          {
            label: 'Certifications',
            desc: 'Recognized certificates on completion.',
            to: '/learning/certifications'
          },
        ],
      },
    ],
  },

  {
    label: 'Community',
    intro: {
      title: 'Build in public, grow together',
      desc: 'Events, hackathons, and a network of ambassadors across campuses.',
      cta: 'See upcoming events',
      to: '/community/events',
    },
    columns: [
      {
        heading: 'Get involved',
        items: [
          {
            label: 'Events',
            desc: 'Workshops, meetups, and webinars.',
            to: '/community/events'
          },
          {
            label: 'Hackathons',
            desc: 'Build, ship, and win prizes.',
            to: '/community/hackathons'
          },
        ],
      },
      {
        heading: 'Grow',
        items: [
          {
            label: 'Ambassador',
            desc: 'Represent Upskillfy on your campus.',
            to: '/community/ambassador'
          },
        ],
      },
    ],
  },

  {
    label: 'Portfolio',
    to: '/portfolio'
  },

  {
    label: 'About',
    to: '/about'
  },
]

export default function Navbar() {
  const [mob, setMob] = useState(false)
  const [openMenu, setOpenMenu] = useState(null)

  const { user, logout } = useAuth()
  const { theme, toggle } = useTheme()
  const navigate = useNavigate()

  const navRef = useRef(null)

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  useEffect(() => {
    const onClick = (e) => {
      if (navRef.current && !navRef.current.contains(e.target)) {
        setOpenMenu(null)
      }
    }

    const onKey = (e) => {
      if (e.key === 'Escape') {
        setOpenMenu(null)
      }
    }

    document.addEventListener('mousedown', onClick)
    document.addEventListener('keydown', onKey)

    return () => {
      document.removeEventListener('mousedown', onClick)
      document.removeEventListener('keydown', onKey)
    }
  }, [])

  useEffect(() => {
    setOpenMenu(null)
  }, [navigate])

  return (
    <>
      <nav className="navbar" ref={navRef}>
        <div className="nav-inner">

          {/* LOGO */}
          <Link to="/" className="logo-wrap">
            <div className="logo-box">U</div>
            <span className="logo-name">
              Upskillfy<span>.</span>
            </span>
          </Link>

          {/* DESKTOP NAVIGATION */}
          <ul className="nav-menu">

            {NAV.map((item, i) =>
              item.columns ? (
                <li key={i}>
                  <button
                    className={`nav-btn${openMenu === i ? ' on' : ''}`}
                    onClick={() =>
                      setOpenMenu(openMenu === i ? null : i)
                    }
                    aria-expanded={openMenu === i}
                  >
                    {item.label}

                    <span
                      className={`nav-caret${openMenu === i ? ' up' : ''
                        }`}
                    >
                      ▾
                    </span>
                  </button>
                </li>
              ) : (
                <li key={i}>
                  <NavLink
                    to={item.to}
                    className={({ isActive }) =>
                      `nav-btn${isActive ? ' on' : ''}`
                    }
                  >
                    {item.label}
                  </NavLink>
                </li>
              )
            )}

          </ul>

          {/* RIGHT ACTIONS */}
          <div className="nav-acts">

            {/* SEARCH */}
            <button
              className="theme-toggle icon-only"
              title="Search"
              aria-label="Search"
            >
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="11" cy="11" r="7" />
                <line
                  x1="21"
                  y1="21"
                  x2="16.65"
                  y2="16.65"
                />
              </svg>
            </button>

            {/* THEME */}
            <button
              onClick={toggle}
              className="theme-toggle"
              title={
                theme === 'dark'
                  ? 'Switch to Light Mode'
                  : 'Switch to Dark Mode'
              }
              aria-label="Toggle theme"
            >

              {theme === 'dark' ? (
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="12" cy="12" r="5" />
                  <line x1="12" y1="1" x2="12" y2="3" />
                  <line x1="12" y1="21" x2="12" y2="23" />
                  <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
                  <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
                  <line x1="1" y1="12" x2="3" y2="12" />
                  <line x1="21" y1="12" x2="23" y2="12" />
                  <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
                  <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
                  <line x1="5.64" y1="18.36" x2="4.22" y2="19.78" />
                  <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
                </svg>
              ) : (
                <svg
                  width="15"
                  height="15"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                >
                  <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                </svg>
              )}

              <span className="theme-label">
                {theme === 'dark' ? 'Light' : 'Dark'}
              </span>

            </button>

            {/* AUTH */}
            {user ? (
              <>
                <Link
                  to="/dashboard"
                  className="btn btn-g btn-sm"
                >
                  Dashboard
                </Link>

                <button
                  onClick={handleLogout}
                  className="btn btn-p btn-sm"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className="btn btn-g btn-sm"
                >
                  Login
                </Link>

                <Link
                  to="/register"
                  className="btn btn-p btn-sm"
                >
                  Join Free
                </Link>
              </>
            )}

            {/* MOBILE MENU */}
            <button
              className="mob-btn"
              onClick={() => setMob(!mob)}
              aria-label="Open navigation"
            >
              {mob ? '✕' : '☰'}
            </button>

          </div>
        </div>

        {/* MEGA MENU */}
        {openMenu !== null &&
          NAV[openMenu].columns && (
            <div className="mega">

              <button
                className="mega-close"
                onClick={() => setOpenMenu(null)}
                aria-label="Close menu"
              >
                ✕
              </button>

              <div className="mega-inner">

                {/* INTRO */}
                <div className="mega-intro">

                  <h3>
                    {NAV[openMenu].intro.title}
                  </h3>

                  <p>
                    {NAV[openMenu].intro.desc}
                  </p>

                  <Link
                    to={NAV[openMenu].intro.to}
                    className="mega-intro-link"
                    onClick={() => setOpenMenu(null)}
                  >
                    {NAV[openMenu].intro.cta} →
                  </Link>

                </div>

                {/* COLUMNS */}
                {NAV[openMenu].columns.map((col, ci) => (
                  <div
                    className="mega-col"
                    key={ci}
                  >

                    <div className="mega-col-h">
                      {col.heading}
                    </div>

                    {col.items.map((it, ii) => (
                      <Link
                        key={ii}
                        to={it.to}
                        className="mega-item"
                        onClick={() => setOpenMenu(null)}
                      >
                        <span className="mega-item-t">
                          {it.label}
                        </span>

                        <span className="mega-item-d">
                          {it.desc}
                        </span>
                      </Link>
                    ))}

                  </div>
                ))}

              </div>
            </div>
          )}

      </nav>

      {/* BACKDROP */}
      {openMenu !== null && (
        <div
          className="mega-backdrop"
          onClick={() => setOpenMenu(null)}
        />
      )}

      {/* MOBILE DRAWER */}
      {mob && (
        <div className="mob-drawer">

          {NAV.map((item, i) =>
            item.columns ? (
              <div key={i}>

                <div className="mob-sec">
                  {item.label}
                </div>

                {item.columns.map((col) =>
                  col.items.map((d, j) => (
                    <Link
                      key={`${i}-${j}`}
                      to={d.to}
                      onClick={() => setMob(false)}
                    >
                      {d.label}
                    </Link>
                  ))
                )}

              </div>
            ) : (
              <Link
                key={i}
                to={item.to}
                onClick={() => setMob(false)}
                style={{
                  fontWeight: 600,
                  color: 'var(--text)'
                }}
              >
                {item.label}
              </Link>
            )
          )}

          {/* MOBILE THEME */}
          <button
            onClick={toggle}
            className="mob-theme-btn"
          >
            {theme === 'dark'
              ? '☀️ Switch to Light Mode'
              : '🌙 Switch to Dark Mode'}
          </button>

          {/* MOBILE AUTH */}
          <div
            style={{
              display: 'flex',
              gap: 10,
              marginTop: 16
            }}
          >

            {user ? (
              <button
                onClick={() => {
                  handleLogout()
                  setMob(false)
                }}
                className="btn btn-p btn-full"
              >
                Logout
              </button>
            ) : (
              <>
                <Link
                  to="/login"
                  className="btn btn-g"
                  style={{
                    flex: 1,
                    justifyContent: 'center'
                  }}
                  onClick={() => setMob(false)}
                >
                  Login
                </Link>

                <Link
                  to="/register"
                  className="btn btn-p"
                  style={{
                    flex: 1,
                    justifyContent: 'center'
                  }}
                  onClick={() => setMob(false)}
                >
                  Join Free
                </Link>
              </>
            )}

          </div>

        </div>
      )}
    </>
  )
}